package com.example.interaksidata

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
